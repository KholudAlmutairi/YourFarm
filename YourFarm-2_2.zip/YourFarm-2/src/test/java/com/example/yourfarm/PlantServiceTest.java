package com.example.yourfarm;

import com.example.yourfarm.API.ApiException;
import com.example.yourfarm.Model.*;
import com.example.yourfarm.Repository.AuthRepository;
import com.example.yourfarm.Repository.FarmRepository;
import com.example.yourfarm.Repository.PlantRepository;
import com.example.yourfarm.Service.PlantService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
public class PlantServiceTest {

    @InjectMocks
    PlantService plantService;

    @Mock
    PlantRepository plantRepository;

    @Mock
    AuthRepository authRepository;
    @Mock
    FarmRepository farmRepository;

    User user;
    Farm farm;

    Plant plant1,plant2,plant3;

    Set<Plant> plants;

    Plant mockPlant = Mockito.mock(Plant.class);
    String name = "star";

    @BeforeEach
    void setUp() {
        user = new User(1,"sara","123","CUSTOMER","SARA","sara@gmail.com","0512345678","esdfyguhio",null,null,null,null,null);
        farm = new Farm(1,"qwertyui","sdfghjk",12345,0.0,0,0,null,null,null,user);

        plant1= new Plant(1,"plant1","QWERT",10,"Indoor plants",1,farm);
        plant2= new Plant(2,"plant2","GHJK",20,"Indoor plants",2,farm);
        plant3= new Plant(3,"plant3","GHJK",30,"Indoor plants",3,farm);
        plants = new HashSet<>();
        plants.add(plant1);
        plants.add(plant2);
        plants.add(plant3);

    }
    @Test
    public void testAddPlant() {

        when(farmRepository.findFarmById(farm.getId())).thenReturn(farm);

        plantService.addPlant(farm.getId(), mockPlant);

        verify(mockPlant).setFarm(farm);

        verify(plantRepository, times(1)).save(mockPlant);
    }

    @Test
    public void testUpdatePlant() {
        // تهيئة البيانات
        when(plantRepository.findPlantById(plant1.getId())).thenReturn(plant1);

        // استدعاء الميثود التي نريد اختبارها
        plantService.update(farm.getId(), plant1.getId(), plant2);

        // التحقق من أن القيم تم تغييرها بشكل صحيح
        assertEquals("plant2", plant1.getName());
        assertEquals("Indoor plants", plant1.getType());
        assertEquals(20, plant1.getPrice());
        assertEquals(2, plant1.getQuantity());

        // التحقق من حفظ التغييرات في المستودع
        verify(plantRepository, times(1)).save(plant2);
    }

    @Test
    public void testUpdateNonExistingPlant() {

        when(plantRepository.findPlantById(plant1.getId())).thenReturn(null);

        ApiException exception = assertThrows(ApiException.class, () -> plantService.update(farm.getId(), plant1.getId(),plant2));

        assertEquals("Plant not found", exception.getMessage());

        verify(plantRepository, never()).save(any());
    }

    @Test
    public void testDeletePlant() {

        when(plantRepository.findPlantById(plant1.getId())).thenReturn(plant1);

        plantService.deletePlant(farm.getId(), plant1.getId());

        verify(plantRepository, times(1)).delete(plant1);
    }

    @Test
    public void testDeleteNonExistingPlant() {

        when(plantRepository.findPlantById(plant2.getId())).thenReturn(null);

        ApiException exception = assertThrows(ApiException.class, () -> plantService.deletePlant(farm.getId(), plant2.getId()));

        assertEquals("Plant not found", exception.getMessage());

        verify(plantRepository, never()).delete(any());
    }

    @Test
    public void testViewPlantOfExistingFarm() {

        String name= "star";
        when(farmRepository.findFarmByUserName(name)).thenReturn(farm);

        // استدعاء الميثود التي نريد اختبارها
        Set<Plant> result = plantService.ViewPlantOfFarm(name);

        // التحقق من أن النباتات المسترجعة تحتوي على جميع النباتات المتوقعة
        assertTrue(result.containsAll(result));
    }

    @Test
    public void testViewPlantOfNonExistingFarm() {
        String name= "star";
        when(farmRepository.findFarmByUserName(name)).thenReturn(null);

        ApiException exception = assertThrows(ApiException.class, () -> plantService.ViewPlantOfFarm(name));

        assertEquals("Farm not found", exception.getMessage());
    }

}
