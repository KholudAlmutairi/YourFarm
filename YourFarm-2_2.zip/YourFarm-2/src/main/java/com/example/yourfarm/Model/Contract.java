package com.example.yourfarm.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Contract {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotEmpty(message = "Contract Details must not be empty")
    @Column(columnDefinition = "varchar(255) not null ")
    private String contractDetails;


    @Pattern(regexp ="^(in progress|finished|waiting|accepted|Canceled)$")
    @Column(columnDefinition = "varchar(12) not null")
    private String status;

//    @Pattern(regexp = "YYYY/MM/DD")
    @NotNull(message = "contractStartingDate should not be empty")
    @Future(message = "contract start date should be set at future")
    private LocalDate contractStartingDate;

    @NotNull(message = "contract end date should not be empty")
    @Future(message = "contract end date should be set at future")
//    @Pattern(regexp = "YYYY/MM/DD")
    private LocalDate contractEndDate;

    //--------------------------------


    @ManyToOne
    @JsonIgnore
    private Company company;

    @ManyToOne
    @JsonIgnore
    private Farm farm;



}
